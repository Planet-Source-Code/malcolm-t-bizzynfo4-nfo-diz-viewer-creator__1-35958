	     Readme File for Hyprfont.zip File



To install the fonts in this zip file you need to do the following:

Unzip this file into a temporary directory.  You should see these files:
	readme.txt	(the file you are reading now)
	Hyperdk.fon	HyperFont Dark
	Hyperlt.fon	HyperFont Light
	Hypertt.ttf	HyperFont TrueType

Open the Windows95 Control Panel .

Open the Fonts folder.

Select File from the Menu and then click on Install New Font

Select the drive and the temporary directory of the new unzipped HyperFonts.

Highlight the font(s) in the "List of fonts" window or click on "Select All".

Click on OK.

The fonts are now installed !!!  You should be able to choose the new HyperFonts from the 
Font dialog box.